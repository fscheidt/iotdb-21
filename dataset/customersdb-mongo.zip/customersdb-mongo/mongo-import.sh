#!/bin/bash

# Script para importar dados no mongodb local

for f in *.json
do
    filename=$(basename "$f")
    extension="${filename##*.}"
    filename="${filename%.*}"
    mongoimport -d customersdb -c "$filename" --type json --file "$f"
done